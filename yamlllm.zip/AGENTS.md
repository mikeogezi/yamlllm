# AGENTS.md

## Info
- Make sure to run commands in the yamlllm conda environment.
- You can activate the environment with `conda activate yamlllm`