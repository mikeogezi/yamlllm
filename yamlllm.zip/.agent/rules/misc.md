---
trigger: always_on
---

If you need general information about the project, look at docs/FEATURES.md and/or docs/PROPOSALS.md