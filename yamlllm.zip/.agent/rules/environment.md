---
trigger: always_on
---

Always check the rules in AGENTS.md