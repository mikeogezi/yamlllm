"""YamlLLM - A declarative DSL for defining decoder-only transformer architectures."""

__version__ = "0.1.0"

