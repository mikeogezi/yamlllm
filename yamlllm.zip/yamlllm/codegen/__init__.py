"""Code generation backends for different frameworks."""

